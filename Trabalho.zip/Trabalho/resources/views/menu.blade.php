@extends('layouts.modelo')

 @section('body')

 


 <script type ="text/javascript">
       
       
       $(document).ready(function(){

           $('#data').mask('00/00/0000 00:0000');
                                   })

    
      </script>


<div class =" mt-5 ">


        <div class ="card-form col-12 col-md-10 offset-md-1 ">



                <div class ="table-responsive">

                        <table id ="tab" border ='1' class ="table table-hover mt-5 ">

                        <tbody>

                        <td > nome </td>
                        <td > email </td>
                        <td > Data de criação </td>

                        @foreach( $list as $dados)

                        <tr>


                                <td> {{ $dados->Nome }} </td>
                                <td> {{ $dados->Email }} </td>
                                <td > <input type="datetime" id="data" value="{{$dados->created_at}}" disabled ></td>

                                <td> <a href ="editar/{{$dados->id}}" class ="btn btn-sm btn-primary" > EDITAR </a> </td>
                                <td> <a  onClick=" confirma({{$dados->id}}) "   class ="btn btn-sm btn-danger" > EXCLUIR </a> </td>



                        </tr>

                        <script>

                                function confirma(id){

                                var conf = confirm("Deseja realmente exluir?")
                                        
                                if( conf ==true){

                                window.location.href = "excluir/"+id

                                        
                                        }

                                }

                </script>


                        @endforeach
                
                        </tbody>

                        </table>

                        
                        <a href ="LoginOff" class ="btn btn-sm btn-primary" > Desconecta </a>

                </diV> 

        </div>    

</div>   

@endsection