@extends('layouts.modelo')

@section('body')


<div class ="container mt-5 ">

<div class ="card-form col-10 col-md-10 offset-md-4">

            <form method="post"  action ="/Autenticar"   >

            @csrf

                
                        
                
                <div> 
                    <label>

                    E-mail
                    <input type ="email" name ="email"   id ="email" placeholder="Email" size ="40"  required class ="form-control" >
                    </label>
                </div> 

                    
                <div> 
                    <label>

                    Senha
                    <input type ="password" name ="password"   id ='senha' minlength ="8" placeholder="senha" size ="40" required class ="mr-5 form-control"  >
                    </label>
                </div> 

                

                <br>
                        
               <div class =" row col-8 ml-5">

                
                        <button type ="submit" class ="btn  btn-primary  ml-1 mt-1"> Conecta </button>

                

                        <a class ="btn  btn-primary  ml-1 mt-1 " href ="/" > Volta </a>
                                    
                </div>

                    
            </form>


 </div>

</div>


@endsection