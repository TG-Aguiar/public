@extends('layouts.modelo')


@section('body')

 

     

      <div class ="container col-12 ">


            <div class="row mt-5 offset-md-5">

                <div>

                    <a href="Loga" class ="btn btn-primary m-2 "> LOGIN </a>

                </div>

                
                <div>

                    <a href="NovoLogin" class =" btn  btn-primary m-2 "> REGISTRA </a>

                </div>

            </div>
          

      </diV>

 


@endsection