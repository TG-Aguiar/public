<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        
        <script type="text/javascript" src="js/jquery.mask.js"></script>

       


    </head>    

    <body>

    <div class ="col-12 col-md-12 ">

            <div class ="p-4 bg-dark">  </div>
            

                <?php echo $__env->yieldContent('body'); ?>


            </div>


    </body>




</html>    <?php /**PATH C:\xampp\htdocs\laravel\Trabalho\resources\views/layouts/modelo.blade.php ENDPATH**/ ?>