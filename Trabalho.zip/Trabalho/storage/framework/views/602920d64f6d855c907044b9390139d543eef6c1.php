<?php $__env->startSection('body'); ?>

<div class ="container mt-5 ">

        <div class ="card-form col-10 col-md-10 offset-md-4">

                    <form   method="post"  action="Atualiza"   >

                    <?php echo csrf_field(); ?>

                            <div>
                                <label > 
                                <input type ="text"  name ="nome2"  placeholder="nome" size ="40" required class ="mr-5 form-control">
                                </label>
                            </div>
                            
                            
                            <div>
                                <label > 
                                <input type ="email"  name ="email2"  placeholder="email" size ="40" required class ="mr-5 form-control">
                                </label>
                            </div>

                            
                            <div>
                                <label > 
                                <input type ="password"  name ="senha"  placeholder="senha" size ="40" required class ="mr-5 form-control">
                                </label>
                            </div>

                            
                            <div>
                                <label > 
                                <input type ="date"  name ="nascimento2"  placeholder="nome" size ="40" required class ="mr-5 form-control">
                                </label>
                            </div>

                            <input type="hidden"  name ="_token"  value="<?php echo e(csrf_token()); ?>">

                        

                        
                        <br>
                                
                       <div class =" row col-8 ml-5">

                        
                                <button type ="submit" class ="btn  btn-primary  ml-1 mt-1"> Salva </button>

                        

                                <a class ="btn  btn-primary  ml-1 mt-1 " href ="/" > Volta </a>
                                            
                        </div>

                            
                    </form>


         </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Trabalho\resources\views/teste.blade.php ENDPATH**/ ?>