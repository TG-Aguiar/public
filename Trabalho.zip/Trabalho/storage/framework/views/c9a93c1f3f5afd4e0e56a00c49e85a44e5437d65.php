<?php $__env->startSection('body'); ?>

 

     

      <div class ="container col-12 ">


            <div class="row mt-5 offset-md-5">

                <div>

                    <a href="Loga" class ="btn btn-primary m-2 "> LOGIN </a>

                </div>

                
                <div>

                    <a href="NovoLogin" class =" btn  btn-primary m-2 "> REGISTRA </a>

                </div>

            </div>
          

      </diV>

 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Trabalho\resources\views/index.blade.php ENDPATH**/ ?>