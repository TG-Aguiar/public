<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
       
         
        <script type="text/javascript" src="js/jquery.min.js"></script>

        <script type="text/javascript" src="js/jquery.mask.min.js"></script>

        
       <script type ="text/javascript">
       
       
       $(document).ready(function(){

           $('.data').mask('00/00/0000 00:0000');
                                   })

    
      </script>

    </head>    

    <body>   


<div class ="p-4 bg-dark">  </div>


<div class ="container mt-5 ">


<div class ="card-form col-12 col-md-10 offset-md-4">

                    <form   method="post"  action="/InsertUsuario/<?php echo e($edit->id); ?>"   >

                    <?php echo csrf_field(); ?>


                            
                                <label > 
                                  Nome
                                <input type ="text"  name ="nome" value="<?php echo e($edit->Nome); ?>"  size ="40" required class ="mr-5 form-control">
                                </label>
                            
                            
                            
                        <div> 
                            <label>
                             E-mail   
                            <input type ="email" name ="email"   value ="<?php echo e($edit->Email); ?>" size ="40"  required class ="form-control" >
                            </label>
                        </div> 

                            
                        <div> 
                            <label>
                             Senha
                            <input type ="password" name ="senha"   value ="<?php echo e($edit->Senha); ?>" minlength ="8"  size ="40" required class ="mr-5 form-control"  >
                            </label>
                        </div> 

                        <div> 
                            <label >
                            Data de Nascimento
                            <input type ="date" name ="nascimento"   value ="<?php echo e($edit->Nascimento); ?>"   class ="form-control" >
                            </label>
                        </div> 

                        <div>

                        criado em :

                        <br>
                
                        <input type="datetime" id="data" class ="data"value="<?php echo e($edit->created_at); ?>" disabled >

                              

                       </div>

                        

                        
                        <br>
                                
                       <div class =" row col-8 ml-5">

                        
                                <button type ="submit" class ="btn  btn-primary  ml-1 mt-1"> Salva </button>

                        

                                <a class ="btn  btn-primary  ml-1 mt-1 " href ="/Menu" > Volta </a>
                                            
                        </div>

                            
                    </form>


         </div>

</div>


</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\Trabalho\resources\views/editando.blade.php ENDPATH**/ ?>