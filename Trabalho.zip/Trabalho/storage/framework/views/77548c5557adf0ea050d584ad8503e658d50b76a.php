 <?php $__env->startSection('body'); ?>

 


 <script type ="text/javascript">
       
       
       $(document).ready(function(){

           $('#data').mask('00/00/0000 00:0000');
                                   })

    
      </script>


<div class =" mt-5 ">


        <div class ="card-form col-12 col-md-10 offset-md-1 ">



                <div class ="table-responsive">

                        <table id ="tab" border ='1' class ="table table-hover mt-5 ">

                        <tbody>

                        <td > nome </td>
                        <td > email </td>
                        <td > Data de criação </td>

                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>


                                <td> <?php echo e($dados->Nome); ?> </td>
                                <td> <?php echo e($dados->Email); ?> </td>
                                <td > <input type="datetime" id="data" value="<?php echo e($dados->created_at); ?>" disabled ></td>

                                <td> <a href ="editar/<?php echo e($dados->id); ?>" class ="btn btn-sm btn-primary" > EDITAR </a> </td>
                                <td> <a  onClick=" confirma(<?php echo e($dados->id); ?>) "   class ="btn btn-sm btn-danger" > EXCLUIR </a> </td>



                        </tr>

                        <script>

                                function confirma(id){

                                var conf = confirm("Deseja realmente exluir?")
                                        
                                if( conf ==true){

                                window.location.href = "excluir/"+id

                                        
                                        }

                                }

                </script>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                        </tbody>

                        </table>

                        
                        <a href ="LoginOff" class ="btn btn-sm btn-primary" > Desconecta </a>

                </diV> 

        </div>    

</div>   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Trabalho\resources\views/menu.blade.php ENDPATH**/ ?>