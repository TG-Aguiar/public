<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('NovoLogin', function(){

    return view('CadastraLogin');

});

Route::post('/Autenticar','ControllerUsuario@login');

Route::post('/InsertUsuario','ControllerUsuario@insert');
Route::post('/InsertUsuario/{id}','ControllerUsuario@update');

Route::get('Loga', function(){

    return view('login');
});

Route::get('LoginOff','ControllerUsuario@desconect');

Route::post('MenuLogin','ControllerUsuario@menu');

Route::get('Menu','ControllerUsuario@menu');


Route::get('excluir/{id}','ControllerUsuario@delete');

Route::get('editar/{id}','ControllerUsuario@edit');


