<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Usuario;

use Illuminate\Support\Facades\DB;


class ControllerUsuario extends Controller
{
    public function insert( Request $request ){


        try{

                $insert = new Usuario();



                $insert-> Nome = $request->input('nome');
                $insert-> Email = $request->input('email');
                $insert-> Senha = $request->input('password');
                $insert-> Nascimento = $request->input('data');
                
                $insert->save();
          

              
               echo " <script>

                     alert('salvo com sucesso')
                     
                     window.location.href= 'Loga'
               
               
               </script> ";
             
               
               
        }

        catch(Exception $e){


            echo " <script>

                          alert('erro!!! Tente Novamente')
            
                           window.location.href= 'index'
      
      
                    </script> ";
            
        }
        

        
    }

    public function login( Request $request){

           $email= $request->input('email');

           $password = $request->input('password');

           $data = DB:: SELECT("select id, nome from  usuarios where Email='$email' and  Senha = '$password' ");

           $cont = count($data);
                    
           if( $cont > 0){

                 session_start();

                $_SESSION['conectado']= $email && $password;

                        if( isset( $_SESSION['conectado'])){
                        

                            return redirect('Menu');


                        }

            }

                    
            else{


                    echo " <script>

                            alert('Dados incorretos')
                    
                            window.location.href= 'Loga'
            
            
                    </script> ";
                    
                }
        
    }

    public function desconect(){
        
        session_start();

            if( isset(  $_SESSION['conectado'] )){
    

            session_destroy();

            return redirect('/');

            }

            else 

              session_destroy();

             return redirect('/');

    }

    public function menu( ){

        session_start();


            if( isset( $_SESSION['conectado'])){
        

              $list = Usuario::all();

              return view('menu',compact('list'));


            }

        else 

            return redirect('/');
    


    }

    public function delete($id){

        session_start();


        if( isset( $_SESSION['conectado'])){
    

                $del = Usuario::find($id);

                $del->delete();

                return redirect('Menu');

        }

        
        else 

                return redirect('/');


    }

    public function edit( $id){

        session_start();


                if( isset( $_SESSION['conectado'])){
            

                $edit = Usuario::find($id);
                
                return view('editando', compact('edit'));

                }

                        
        else 

                return redirect('/');


    }

    public function update( Request $request, $id){

        session_start();


        if( isset( $_SESSION['conectado'])){

                $insert = Usuario::find($id);
                
            
                $insert-> Nome = $request->input('nome');
                $insert-> Email = $request->input('email');
                $insert-> Senha = $request->input('senha');
                $insert-> Nascimento = $request->input('nascimento');

                $insert->save();

            $insert->save();

                return redirect('Menu');

        }

            
        else 

                return redirect('/');

        


    }

    


}
